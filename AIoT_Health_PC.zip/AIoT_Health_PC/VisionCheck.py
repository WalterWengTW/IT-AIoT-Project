# -*- coding: utf-8 -*-
#********************************************************************************************
#***                                  Module Importing                                    ***
#********************************************************************************************
from darkflow.net.build import TFNet
import cv2
import winsound
import os
import random
import datetime
import csv
import tkinter as tk
from PIL import Image, ImageTk
import Menu_Page
import PlotPage
from linebot import LineBotApi
from linebot.models import TextSendMessage

class VisionCheck(object):
    
    def __init__(self, master=None):
        # Images Load in ==============================================================================
        self.Vision_Img = tk.PhotoImage(file = './bin/5M視標/left2.png')
        self.LINE_Img = tk.PhotoImage(file = './bin/icon/LINE.png')
        self.BackPage_Img = tk.PhotoImage(file = './bin/icon/previous.png')
        self.Reset_Img = tk.PhotoImage(file = './bin/icon/Reset.png')
        self.Plot_Img = tk.PhotoImage(file = './bin/icon/plot.png')
        
        # Variable of Vision Check ====================================================================
        self.DirectionDict = ['up', 'down', 'left', 'right'] #test
        self.LeadLibrary = ["請將手放置十字紅點，等待紅點變成綠點", "Ready，請手勢觸碰不同方向的箭頭 !", "測試已結束，謝謝!"]
        self.StateString = tk.StringVar() #var2
        self.SymbolPointer = 2   #z
        self.SymbolDirect = 'left' #y
        self.CorrectOrNot = False #correct, wrong 
        self.WrongCounter = 0
        self.Action = ''  #var
        self.VisionState = '' #var1
        self.LeadString = tk.StringVar()
        self.LeadString.set(self.LeadLibrary[0])
        self.ImageChangeDelayCount = 0 #20190606 Delay use
        self.indexIns = 0
        self.AsyncCounter = 0
        self.cum = 0
        self.CheckTime = datetime.datetime.now()
        
        # Hand detection variable =====================================================================
        self.center_x = 320
        self.center_y = 240
        self.ArrowXtop = 180
        self.ArrowXbtm = 460
        self.ArrowYtop = 120
        self.ArrowYbtm = 360
        self.Ready = False
        self.Direct = 0
        self.WaveCount = 0
        self.Hand_Left = 0
        self.Hand_Right = 0
        self.Hand_Left_pre = 0
        self.Hand_Right_pre = 0
        #self.DelayCount = 0
        self.Enable = True
        self.DistBoxXtop = 280
        self.DistBoxXbtm = 360
        self.DistBoxYtop = 190
        self.DistBoxYbtm = 290
        
        
        #Initialization================================================================================
        self.camera = cv2.VideoCapture(1)
        self.tfnet = self.NetInitialize()
        
        #Generate Frame ===============================================================================
        self.root = master
        self.root.title('AIoT Health - Vision Check')
        self.root.geometry(('1280x600'))
        self.root.geometry('+0+0')
        self.root.resizable(False, False)
        self.page = tk.Frame(self.root)
        self.page.pack(expand=True, fill=tk.BOTH)
        
        #Vision Image =================================================================================
        self.VisionLabel = tk.Label(self.page, image = self.Vision_Img)
        self.VisionLabel.place(x=100, y=75)
        
        self.StateLabel = tk.Label(self.page, bg='LightGray', width=13, height=2, wraplength=210,
                                   justify = 'left',font=('Arial',20),textvariable = self.StateString)
        self.StateLabel.place(x=400, y=500)
        self.InsFramesReady=[]
        for frame in range(1,20):
            ImageDirectory = 'bin\images\gifReady\%d.png'%frame
            self.InsFramesReady.append(tk.PhotoImage(file=ImageDirectory))
        
        self.InsFramesDirect=[]
        for frame in range(1,23):
            ImageDirectory = 'bin\images\gifDirect\%d.png'%frame
            self.InsFramesDirect.append(tk.PhotoImage(file=ImageDirectory))
            
        self.InsFramesEnd =None
        ImageDirectory = 'bin\images\End.png'
        self.InsFramesEnd = tk.PhotoImage(file=ImageDirectory)
            
            
        self.InsPanel = tk.Label(self.page, width=120, height=90)
        self.InsPanel.place(x=0, y=0)
        
        self.LeadLabel = tk.Label(self.page, bg='LightGray', width=30, height=2, wraplength=400,
                                   justify = 'left',font=('Arial',20), textvariable = self.LeadString, fg="Red", anchor="w")
        self.LeadLabel.place(x=125, y=5)

        #Control object ===============================================================================
        self.BackButton = tk.Button(self.page, text= "Back to menu",bg = 'White',font=('Arial',14),command = self.BackToMenu)
        self.BackButton.config(image = self.BackPage_Img)
        self.BackButton.place(x=5, y=500)
        
        self.PushButton = tk.Button(self.page,text="Send LINE Message", bg='White', font=('Arial',14), command=self.LINEpush)
        self.PushButton.config(image = self.LINE_Img)
        self.PushButton.place(x=105, y=500)
        
        self.ResetButton = tk.Button(self.page,text="Reset", bg='White', font=('Arial',14), command=self.ResetCheck)
        self.ResetButton.config(image = self.Reset_Img)
        self.ResetButton.place(x=205, y=500)
        
        self.PlotButton = tk.Button(self.page,text="PlotPage", bg='White', font=('Arial',14), command=self.PlotPage)
        self.PlotButton.config(image = self.Plot_Img)
        self.PlotButton.place(x=305, y=500)
        
        
        
#        self.UpButton = tk.Button(self.page,text="up",pady=2,padx=13,command=self.Up_action)
#        self.UpButton.place(x=0, y=350)
#        self.DownButton = tk.Button(self.page,text="down",pady=2,padx=4,command=self.Down_action)
#        self.DownButton.place(x=60, y=350)
#        self.NoneButton = tk.Button(self.page,text="none",pady=2,padx=6,fg="red",command=self.NotClear_action)
#        self.NoneButton.place(x=120, y=350)
#        self.LeftButton = tk.Button(self.page,text="left",pady=2,padx=11,command=self.Left_action)
#        self.LeftButton.place(x=180, y=350)
#        self.RightButton = tk.Button(self.page,text="right",pady=2,padx=6,command=self.Right_action)
#        self.RightButton.place(x=240, y=350)
        
        #Video Panel ==================================================================================
        self.panel = tk.Label(self.page)
        self.panel.pack(padx=10, pady=10, side='right')
        self.VideoLoop()
        self.root.protocol("WM_DELETE_WINDOW", self.Closing)
        
    # Video function ==================================================================================
    def Closing(self):
        self.camera.release()
        cv2.destroyAllWindows()
        self.page.destroy()
        self.root.destroy()
        
    def VideoLoop(self):
        success, frame = self.camera.read() 
        if success:
            frame  = cv2.flip(frame , 1)
            frame_pre  = cv2.cvtColor(frame , cv2.COLOR_BGR2GRAY)
            frame_pre  = cv2.cvtColor(frame_pre, cv2.COLOR_GRAY2BGR)
            result = self.tfnet.return_predict(frame_pre)
            frame_re = self.Detecting(frame, result)
            cv2.waitKey(1)
            cv2image = cv2.cvtColor(frame_re, cv2.COLOR_BGR2RGBA)
            current_image = Image.fromarray(cv2image)
            imgtk = ImageTk.PhotoImage(image=current_image)
            self.panel.imgtk = imgtk
            self.panel.config(image=imgtk)
            self.panel.image_names = imgtk
            
        self.AsyncCounter += 1
        
        if self.AsyncCounter == 3:
            self.AsyncCounter = 0
        
            if (not self.Ready) & self.Enable:
                self.indexIns += 1
                self.indexIns %= 19
                frames = self.InsFramesReady[self.indexIns]
            elif self.Ready & self.Enable:
                self.indexIns += 1
                self.indexIns %= 22
                frames = self.InsFramesDirect[self.indexIns]
            else:
                frames = self.InsFramesEnd
            self.InsPanel.configure(image=frames)
            
        self.page.after(10, self.VideoLoop)


    # Detection function ==============================================================================
    def NetInitialize(self):
        options = {"pbLoad": "bin/YOLO_WEIGHTS/tiny-yolo-hand-detect.pb", "threshold": 0.3,
                   "metaLoad": "bin/YOLO_WEIGHTS/tiny-yolo-hand-detect.meta", "gpu": 1.0}
    
        return TFNet(options)

    def GetOnlyOneBox(self,predictions):
        MaxConfidenceSet = {'label': ' ', 'top_x': 0.0, 'top_y': 0.0, 'btm_x': 0.0, 'btm_y': 0.0, 'confidence' : 0.0}
        for result in predictions:
            if result['confidence']>MaxConfidenceSet['confidence']:
                MaxConfidenceSet['label'] = result['label']
                MaxConfidenceSet['top_x'] = result['topleft']['x']
                MaxConfidenceSet['top_y'] = result['topleft']['y']
                MaxConfidenceSet['btm_x'] = result['bottomright']['x']
                MaxConfidenceSet['btm_y'] = result['bottomright']['y']
                MaxConfidenceSet['confidence'] = round(result['confidence'], 3)
    
        return MaxConfidenceSet
    
    def CenterIOU(self, BoxPredict):
        top_x, top_y = BoxPredict[0], BoxPredict[1]
        btm_x, btm_y = BoxPredict[2], BoxPredict[3]      
        PredictArea = (top_x-btm_x)*(top_y-btm_y)
        CenterArea = (self.DistBoxXtop-self.DistBoxXbtm)*(self.DistBoxYtop-self.DistBoxYbtm)
        Intersection_Xtop, Intersection_Ytop= max(top_x, self.DistBoxXtop), max(top_y, self.DistBoxYtop)
        Intersection_Xbtm, Intersection_Ybtm= min(btm_x, self.DistBoxXbtm), min(btm_y, self.DistBoxYbtm)
        InterArea = (Intersection_Xtop-Intersection_Xbtm)*(Intersection_Ytop-Intersection_Ybtm)
        IOU = InterArea/(PredictArea+CenterArea-InterArea)
        
        return IOU
        

    def Detecting(self, Image, predictions):

        MaxConfidenceSet = self.GetOnlyOneBox(predictions)
        top_x, top_y = MaxConfidenceSet['top_x'], MaxConfidenceSet['top_y']
        btm_x, btm_y = MaxConfidenceSet['btm_x'], MaxConfidenceSet['btm_y']
        box_x, box_y = (top_x+btm_x)/2, (top_y+btm_y)/2  
        BoxPredict = [top_x, top_y, btm_x, btm_y] 
        #print(self.CenterIOU(BoxPredict))
        IOU_handcenter = self.CenterIOU(BoxPredict)
        if self.Ready:
            Image = cv2.line(Image, (self.center_x-10,self.center_y), (self.center_x+10,self.center_y), (0, 255, 0), 3)
            Image = cv2.line(Image, (self.center_x,self.center_y-10), (self.center_x,self.center_y+10), (0, 255, 0), 3)
            if self.Enable:
                self.LeadString.set(self.LeadLibrary[1])
    
        else:
            Image = cv2.line(Image, (self.center_x-10,self.center_y), (self.center_x+10,self.center_y), (0, 0, 255), 3)
            Image = cv2.line(Image, (self.center_x,self.center_y-10), (self.center_x,self.center_y+10), (0, 0, 255), 3)
            Image = cv2.rectangle(Image, (self.DistBoxXtop,self.DistBoxYtop), (self.DistBoxXbtm,self.DistBoxYbtm), (0, 0, 255), 3)
            if self.Enable:
                self.LeadString.set(self.LeadLibrary[0])
        
        if self.Direct == 1:
            Image = cv2.line(Image, (self.ArrowXtop,self.center_y), (self.ArrowXtop-60 ,self.center_y), (0, 255, 0), 5)
            Image = cv2.line(Image, (self.ArrowXtop-60,self.center_y), (self.ArrowXtop-60+15 ,self.center_y-15), (0, 255, 0), 5)
            Image = cv2.line(Image, (self.ArrowXtop-60,self.center_y), (self.ArrowXtop-60+15 ,self.center_y+15), (0, 255, 0), 5)
            
        elif self.Direct == 2:
            Image = cv2.line(Image, (self.ArrowXbtm,self.center_y), (self.ArrowXbtm+60 ,self.center_y), (0, 255, 0), 5)
            Image = cv2.line(Image, (self.ArrowXbtm+60,self.center_y), (self.ArrowXbtm+60-15 ,self.center_y-15), (0, 255, 0), 5)
            Image = cv2.line(Image, (self.ArrowXbtm+60,self.center_y), (self.ArrowXbtm+60-15 ,self.center_y+15), (0, 255, 0), 5)
    
        elif self.Direct == 3:
            Image = cv2.line(Image, (self.center_x, self.ArrowYtop), (self.center_x ,self.ArrowYtop-60), (0, 255, 0), 5)
            Image = cv2.line(Image, (self.center_x, self.ArrowYtop-60), (self.center_x-15 ,self.ArrowYtop-60+15), (0, 255, 0), 5)
            Image = cv2.line(Image, (self.center_x, self.ArrowYtop-60), (self.center_x+15 ,self.ArrowYtop-60+15), (0, 255, 0), 5)
        
        elif self.Direct == 4:
            Image = cv2.line(Image, (self.center_x, self.ArrowYbtm), (self.center_x, self.ArrowYbtm+60), (0, 255, 0), 5)
            Image = cv2.line(Image, (self.center_x, self.ArrowYbtm+60), (self.center_x-15, self.ArrowYbtm+60-15), (0, 255, 0), 5)
            Image = cv2.line(Image, (self.center_x, self.ArrowYbtm+60), (self.center_x+15, self.ArrowYbtm+60-15), (0, 255, 0), 5)
            
        else:
            Image = cv2.line(Image, (self.ArrowXtop,self.center_y), (self.ArrowXtop-60 ,self.center_y), (0, 0, 255), 5)
            Image = cv2.line(Image, (self.ArrowXtop-60,self.center_y), (self.ArrowXtop-60+15 ,self.center_y-15), (0, 0, 255), 5)
            Image = cv2.line(Image, (self.ArrowXtop-60,self.center_y), (self.ArrowXtop-60+15 ,self.center_y+15), (0, 0, 255), 5)
            
            Image = cv2.line(Image, (self.ArrowXbtm,self.center_y), (self.ArrowXbtm+60 ,self.center_y), (0, 0, 255), 5)
            Image = cv2.line(Image, (self.ArrowXbtm+60,self.center_y), (self.ArrowXbtm+60-15 ,self.center_y-15), (0, 0, 255), 5)
            Image = cv2.line(Image, (self.ArrowXbtm+60,self.center_y), (self.ArrowXbtm+60-15 ,self.center_y+15), (0, 0, 255), 5)
        
            Image = cv2.line(Image, (self.center_x, self.ArrowYtop), (self.center_x ,self.ArrowYtop-60), (0, 0, 255), 5)
            Image = cv2.line(Image, (self.center_x, self.ArrowYtop-60), (self.center_x-15 ,self.ArrowYtop-60+15), (0, 0, 255), 5)
            Image = cv2.line(Image, (self.center_x, self.ArrowYtop-60), (self.center_x+15 ,self.ArrowYtop-60+15), (0, 0, 255), 5)
        
            Image = cv2.line(Image, (self.center_x, self.ArrowYbtm), (self.center_x, self.ArrowYbtm+60), (0, 0, 255), 5)
            Image = cv2.line(Image, (self.center_x, self.ArrowYbtm+60), (self.center_x-15, self.ArrowYbtm+60-15), (0, 0, 255), 5)
            Image = cv2.line(Image, (self.center_x, self.ArrowYbtm+60), (self.center_x+15, self.ArrowYbtm+60-15), (0, 0, 255), 5)
            

        if MaxConfidenceSet['confidence']> 0.2:
#            label = MaxConfidenceSet['label'] + " " + "%.2f"%(IOU_handcenter)
#            Image = cv2.rectangle(Image, (top_x, top_y), (btm_x, btm_y), (255,0,0), 3)
#            Image = cv2.putText(Image, label, (top_x, top_y-5), cv2.FONT_HERSHEY_COMPLEX_SMALL , 0.8, (0, 230, 0), 1, cv2.LINE_AA)
            if (self.center_x > top_x and self.center_x < btm_x) and (self.center_y > top_y and self.center_y < btm_y) and IOU_handcenter>0.6:
                if not self.Ready:
                    winsound.PlaySound(r"./bin/Sounds/crrect_answer3.wav", winsound.SND_FILENAME|winsound.SND_ASYNC|winsound.SND_NOWAIT)
                    self.Ready = True
                    self.WaveCount = 0
                    self.Direct = 0
                    self.DelayCount = 50
            if box_x < self.ArrowXtop and (box_y>self.ArrowYtop and box_y<self.ArrowYbtm) and int(self.Ready):
                if not self.Direct:
                    winsound.PlaySound(r"./bin/Sounds/left.wav", winsound.SND_FILENAME|winsound.SND_ASYNC|winsound.SND_NOWAIT)
                    self.Direct = 1 #left

            elif box_x > self.ArrowXbtm and (box_y>self.ArrowYtop and box_y<self.ArrowYbtm) and int(self.Ready):
                if not self.Direct:
                    winsound.PlaySound(r"./bin/Sounds/right.wav", winsound.SND_FILENAME|winsound.SND_ASYNC|winsound.SND_NOWAIT)
                    self.Direct = 2 #right

            elif box_y < self.ArrowYtop and (box_x>self.ArrowXtop and box_x<self.ArrowXbtm) and int(self.Ready):
                if not self.Direct:
                    winsound.PlaySound(r"./bin/Sounds/up.wav", winsound.SND_FILENAME|winsound.SND_ASYNC|winsound.SND_NOWAIT)
                    self.Direct = 3 #top

            elif box_y > self.ArrowYbtm and (box_x>self.ArrowXtop and box_x<self.ArrowXbtm) and int(self.Ready):
                if not self.Direct:
                    winsound.PlaySound(r"./bin/Sounds/down.wav", winsound.SND_FILENAME|winsound.SND_ASYNC|winsound.SND_NOWAIT)
                    self.Direct = 4 #bottom

            else:
                self.Direct = self.Direct  
                
            if box_x < self.center_x-20 and int(self.Ready):
                self.Hand_Left = 1
                self.Hand_Right = 0
            elif box_x > self.center_x+20 and int(self.Ready):
                self.Hand_Left = 0
                self.Hand_Right = 1
            else:
                self.Hand_Left = 0
                self.Hand_Right = 0
            
            if self.Hand_Left != self.Hand_Left_pre and self.Hand_Left == 1 and int(self.Ready):
                self.WaveCount += 1
                self.Hand_Left_pre = self.Hand_Left
                self.Hand_Right_pre = self.Hand_Right
            if self.Hand_Right != self.Hand_Right_pre and self.Hand_Right == 1 and int(self.Ready):
                self.WaveCount += 1
                self.Hand_Left_pre = self.Hand_Left
                self.Hand_Right_pre = self.Hand_Right
            if self.WaveCount >= 4 and int(self.Ready):
                winsound.PlaySound(r"./bin/Sounds/NotClear.wav", winsound.SND_FILENAME|winsound.SND_ASYNC|winsound.SND_NOWAIT)
                self.Direct = 5
                self.WaveCount = 0
                
        if self.Direct != 0:
            self.ImageChangeDelayCount += 1
            if self.ImageChangeDelayCount == 50:
                self.ImageChangeDelayCount = 0
                self.DelayCount = 0
                if self.Direct == 1:
                    self.Direct = 0
                    self.Ready = False
                    if self.Enable:
                        self.Left_action()       
                elif self.Direct == 2:
                    self.Direct = 0
                    self.Ready = False
                    if self.Enable:
                        self.Right_action() 
                elif self.Direct == 3:
                    self.Direct = 0
                    self.Ready = False
                    if self.Enable:
                        self.Up_action()
                elif self.Direct == 4:
                    self.Direct = 0
                    self.Ready = False
                    if self.Enable:
                        self.Down_action()
                elif self.Direct == 5:
                    self.Direct = 0
                    self.Ready = False
                    if self.Enable:
                        self.NotClear_action()
                else:
                    pass
                
        return Image

    # Other function ==================================================================================
    def BackToMenu(self):
        self.page.destroy()
        Menu_Page.MenuPage(self.root)

    
    def LINEpush(self):
        with open('User/usr_test.txt','r') as usr_file:
            usr = usr_file.read()
        CheckedUser = '用戶名稱 : %s \n'%(usr)
        CheckedTime = '測驗時間 : %d/%d/%d %d:%d:%d'%(self.CheckTime.year,self.CheckTime.month,self.CheckTime.day,self.CheckTime.hour, self.CheckTime.minute, self.CheckTime.second)+'\n'
        result = '視力檢查結果 : '+str(round(self.SymbolPointer/10,1))
        messagePush = CheckedUser+CheckedTime+result
        Channel_access_token = "g7b9MysQYKOEs1zRV9IVVaQbZUNleS5fJbHG70mZsrkatN2BvxOdEi5tPQ0DXSD3qiGwgGzTlcCR70UlgZaqgwlQN1WomFyv45WIpnYl/852pkIJfd0OXhQtt8c7y+Oq/mnBNN7CzfCTxCV3dpw2ugdB04t89/1O/w1cDnyilFU="
        userID = "Ucc118f0dc0da83b6c2eaf414121490b1"
        line_bot_api = LineBotApi(Channel_access_token)
        txtMessage = TextSendMessage(text = messagePush)
        line_bot_api.push_message(userID, txtMessage)
        
        
    def ResetCheck(self):
        self.Ready = False
        self.Direct = 0
        self.WaveCount = 0
        self.Hand_Left = 0
        self.Hand_Right = 0
        self.Hand_Left_pre = 0
        self.Hand_Right_pre = 0
        self.Enable = True
        self.cum = 0
        
        self.SymbolPointer = 2   #z
        self.SymbolDirect = 'left' #y
        self.CorrectOrNot = False #correct, wrong 
        self.WrongCounter = 0
        self.Action = ''  #var
        self.VisionState = '' #var1
        self.LeadString.set(self.LeadLibrary[0])
        self.ImageChangeDelayCount = 0 #20190606 Delay use
        self.VisionLabel.configure(image = self.Vision_Img)
        self.VisionLabel.image_names = self.Vision_Img
        self.VisionLabel.update_idletasks()
    
    def PlotPage(self):
        self.page.destroy()
        PlotPage.PlotPage(self.root)
        
    
    # Action function =================================================================================
    def Up_action(self):
        self.Action = 'up'
        if self.Action == self.SymbolDirect:
            self.CorrectOrNot = True
        else:
            self.CorrectOrNot = False
        #self.VisionState = "%.1f"%(self.SymbolPointer*0.1)
        self.AfterAction()
        
    def Down_action(self):
        self.Action = 'down'
        if self.Action == self.SymbolDirect:
            self.CorrectOrNot = True
        else:
            self.CorrectOrNot = False
        #self.VisionState = "%.1f"%(self.SymbolPointer*0.1)
        self.AfterAction()
        
    def Left_action(self):
        self.Action = 'left'
        if self.Action == self.SymbolDirect:
            self.CorrectOrNot = True
        else:
            self.CorrectOrNot = False
        #self.VisionState = "%.1f"%(self.SymbolPointer*0.1)
        self.AfterAction()   
        
    def Right_action(self):
        self.Action = 'right'
        if self.Action == self.SymbolDirect:
            self.CorrectOrNot = True
        else:
            self.CorrectOrNot = False
        #self.VisionState = "%.1f"%(self.SymbolPointer*0.1)
        self.AfterAction()
    
    def NotClear_action(self):
        self.Action = 'Not Clear'
        self.CorrectOrNot = False
        #self.VisionState = "%.1f"%(self.SymbolPointer*0.1)
        self.AfterAction()
    
    def result(self,vision):

        self.window_result = tk.Toplevel(self.root)
        self.window_result.geometry('600x500')
        self.window_result.title('Finish')
        tk.Label(self.window_result,font=('Arial',80), width=25,
                  height=3, text='今日視力\n檢測結果:\n ' + "%.1f"%((vision)*0.1)).pack()     
        #self.window_result.protocol("WM_DELETE_WINDOW", self.JumpOutClosing)
        
       
    def AfterAction(self):
        self.cum+=1
        self.StateString.set('目前視力：'+self.VisionState+'\n'+'目前題數：'+str(self.cum-self.WrongCounter)+'/'+str(self.cum))
        ImageDirectory='./bin/5M視標/'
        if self.CorrectOrNot:
            self.SymbolPointer += 1
            if self.SymbolPointer == 11:    
                self.SymbolPointer -= 1
                vision=self.SymbolPointer
                self.RecordingCSV()
                self.Enable = False
                self.Ready = False
                self.LeadString.set(self.LeadLibrary[2])
                self.result(vision)
        else:
            self.WrongCounter += 1
            self.SymbolPointer -= 1
            if self.SymbolPointer < 2:
                self.SymbolPointer = 2
        
        if self.WrongCounter >= 3:
            self.SymbolPointer -= 1
            vision=self.SymbolPointer
            self.RecordingCSV()
            self.Enable = False
            self.Ready = False
            self.LeadString.set(self.LeadLibrary[2])
            self.result(vision) 

#        else:
#            pass
        self.VisionState = "%.1f"%(self.SymbolPointer*0.1)
#        if self.SymbolPointer > 10:
#            self.SymbolPointer = 10
        self.SymbolDirect = self.DirectionDict[random.randint(0,3)]

                
        NextImage = '{0}{1}.png'.format(self.SymbolDirect, self.SymbolPointer)
        if self.SymbolPointer < 2:
            NextImage = '{0}{1}.png'.format(self.SymbolDirect, self.SymbolPointer+1)
            
        ImagePath = os.path.join(ImageDirectory, NextImage)
        ImageDir = tk.PhotoImage(file = ImagePath)
        self.VisionLabel.configure(image = ImageDir)
        self.VisionLabel.image_names = ImageDir
        self.VisionLabel.update_idletasks()
        self.StateString.set('目前視力：'+self.VisionState+'\n'+'目前題數：'+str(self.cum-self.WrongCounter)+'/'+str(self.cum))
        
    def RecordingCSV(self):
        with open('User/usr_test.txt','r') as usr_file:
            usr = usr_file.read()
        self.CheckTime = datetime.datetime.now()
        column = ['ID', 'Date/Time', 'Result']
        data = [usr, '%d/%d/%d %d:%d:%d'%(self.CheckTime.year,self.CheckTime.month,self.CheckTime.day,self.CheckTime.hour, self.CheckTime.minute, self.CheckTime.second),
                "%.1f"%(self.SymbolPointer*0.1)]
        try:
            with open('UserRecord/'+usr+'.csv','r') as usr_file:
                pass
            with open('UserRecord/'+usr+'.csv','a') as usr_file:
                writer = csv.writer(usr_file, lineterminator='\n')
                writer.writerow(data)
            usr_file.close()   
        except FileNotFoundError:
            with open('UserRecord/'+usr+'.csv','w') as usr_file:
                writer = csv.writer(usr_file, lineterminator='\n')
                writer.writerow(column)
            with open('UserRecord/'+usr+'.csv','a') as usr_file:
                writer = csv.writer(usr_file, lineterminator='')
                writer.writerow(data) 
            usr_file.close()

if __name__ == '__main__':

    root = tk.Tk()
    obj = VisionCheck(root)
    root.mainloop()   
    obj.camera.release()
    cv2.destroyAllWindows()
