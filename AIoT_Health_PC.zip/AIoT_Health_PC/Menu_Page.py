
# -*- coding: UTF-8 -*-
import tkinter as tk
import VisionCheck
import PlotPage


class MenuPage: 
        
    def __init__(self,master = None):
        self.root = master
        self.root.title('AIoT Health Menu')
        self.root.geometry(('1280x500'))
        self.root.geometry('+0+0')
        self.root.resizable(False, False)
             
        self.page=tk.Frame(self.root, height = 500,width = 1280)
        self.page.pack(expand=True, fill=tk.BOTH)
        self.lb1=tk.LabelFrame(self.page, width=500, height=400, text='功能選單')
        self.lb1.config(font=('Arail',40,'bold'),fg= "darkred")
        self.lb1.pack(expand=True)
        self.lb1.place(x=400,y=30)
         
        self.action1= tk.Button(self.page, text='確認', command=self.clickMe, width=10,
              height=1,bg = 'LightBlue',font=('Arial',20, 'bold'))
        self.action1.place(x=540 , y=440) 
        
        self.var = tk.StringVar()
        self.r1 = tk.Radiobutton(self.lb1, text='視力檢測',variable=self.var, 
                                 value='視力檢測',command=self.print_selection, 
                                 font=('Arial',20))
        self.r1.place(x=50 , y=30) 
        
        self.r2 = tk.Radiobutton(self.lb1, text='血壓檢測',
                                 variable=self.var, value='血壓檢測',
                                 command=self.print_selection,font=('Arial',20))
        self.r2.place(x=50 , y=100) 
        
        self.r3 = tk.Radiobutton(self.lb1, text='血糖檢測',
                                 variable=self.var, value='血糖檢測',
                                 command=self.print_selection,font=('Arial',20))
        self.r3.place(x=50 , y=170) 
        
       
        self.r4 = tk.Radiobutton(self.lb1, text='健康趨勢分析',
                                 variable=self.var, value='健康趨勢分析',
                                 command=self.print_selection,font=('Arial',20))
        
        self.r4.place(x=50 , y=240) 

        self.var.set(1)    #1預設表單不點選

        
    def print_selection(self):
        if(self.var.get()=='視力檢測'):
            self.r1.config(fg = 'blue')
   
        else: 
            self.r1.config(fg ='black')
            
        if(self.var.get()=='血壓檢測'):
            self.r2.config(fg = 'blue')
        else:
            self.r2.config(fg ='black')
            
        if(self.var.get()=='血糖檢測'):
            self.r3.config(fg = 'blue')
        else:
            self.r3.config(fg ='black')
            
        if(self.var.get()=='健康趨勢分析'):
            self.r4.config(fg = 'blue')
        else:
            self.r4.config(fg ='black')

 
    def clickMe(self):
        #print ("click") #按钮
        
        if(self.var.get()=='視力檢測'):
            self.page.destroy()
            self.Testpage()
        elif (self.var.get()=='血壓檢測'):
            self.page.destroy()
            print(1)
        elif (self.var.get()=='血糖檢測'):
            self.page.destroy()
            print(2)
    
        elif (self.var.get()=='健康趨勢分析'):
            print(3)
            self.Plotpage()

        else:
            print(4)
            
      
    def Testpage(self):
        self.page.destroy()
        VisionCheck.VisionCheck(self.root)     
        
    def Plotpage(self):
        self.page.destroy()
        PlotPage.PlotPage(self.root)   
        

if __name__ == '__main__':      

    root = tk.Tk()
    app = MenuPage(root)
    root.mainloop()

