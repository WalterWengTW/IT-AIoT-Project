import tkinter as tk

import matplotlib
matplotlib.use('TkAgg')
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
from matplotlib.figure import Figure

# seaborn example
import pandas as pd
import matplotlib.pyplot as plt
import Menu_Page
import base64
import to_http
import json
class PlotPage(object):
    def __init__(self, master=None):
        self.root = master
        self.root.title('Embedding in Tk')
        self.root.geometry(('1280x500'))
        self.page = tk.Frame(self.root)
        self.page.pack(expand=True, fill=tk.BOTH)
        self.fig = self.create_plot()
        self.label = tk.Label(self.page, text="Matplotlib with Seaborn in Tkinter")
        self.label.pack()
        self.canvas = FigureCanvasTkAgg(self.fig, master=self.root)  # A tk.DrawingArea.
        
        self.canvas.get_tk_widget().pack(side=tk.TOP,fill=tk.BOTH,expand=1)
        self.canvas.draw()
        self.buttonA = tk.Button(self.page,text="返回選單", bg = 'LightBlue',font=('Arial',10), width=13,
                  height=2,command=self.BackToMenu)
        self.buttonA.pack(side=tk.RIGHT)
        self.buttonB = tk.Button(self.page,text="傳送至LINE", bg = 'LightGreen',font=('Arial',10), width=13,
                  height=2,command=self.transport_Line)
        self.buttonB.pack(side=tk.RIGHT)
        
    def BackToMenu(self):
        self.canvas.get_tk_widget().destroy()
        self.page.destroy()
        Menu_Page.MenuPage(self.root)
        
    def create_plot(self):
        
        with open('User/usr_test.txt', 'r') as usr_file:
            usr = usr_file.read()
        df = pd.read_csv('UserRecord/'+usr+'.csv')
        x=df['Time']
        y=df['Result']
               
#        f = plt.figure(  )
#        ax = f.add_axes([0.05, 0.18, 0.84, 0.80])
#        plt.xticks(rotation="vertical")
#        plt.plot(x, y,'bo')
#        plt.plot(x, y)
#        ax.set_xlabel('Date')
#        ax.set_ylabel('vision')
        fig = Figure(figsize=(15,10),tight_layout=True)
        axes = fig.add_subplot(111)
        axes.plot(x,y,'bo')
        axes.plot(x,y)
        axes.tick_params(labelrotation=90)
        axes.set_xlabel('Date')
        axes.set_ylabel('vision')
        return fig
#        return f
    
    def transport_Line(self):
        self.fig.savefig('usr_test.jpg')
        encoded_string = None
        with open("usr_test.jpg", "rb") as image_file:
            encoded_string = base64.b64encode(image_file.read())
        filename='usr_test'
        payload={'topic':'classification','message':filename, 'img':encoded_string.decode("utf-8")}
        to_http.MessagePush(payload,method='mqtt')
        payload_link={}
        url='https://4ed62cea.ngrok.io/www/'+filename+ '.jpg'
        payload_link['topic']='image'
        payload_link['message']=url
        to_http.MessagePush(payload_link,method='line')
        
    # --- main ---

    
    
    
    


if __name__ == '__main__':

    root = tk.Tk()
    obj = PlotPage(root)
    root.mainloop()   
