# coding: utf-8

#conda install requests

import requests
header={'content-type': 'application/json'}
#agent='http://220.132.124.155:3010/agent/'
agent='https://bd315a38.ngrok.io/agent/'

## '0':mqtt, '1': line',2:'email',3:'ftp',4:'sms',5:'websocket'
def MessagePush(payload='test',method='mqtt'):
    url=agent+method
    ret = requests.post(url,json=payload)
    status=ret.json()
    print(ret.status_code)  #get 200 oK if success
    return ret,status
    
