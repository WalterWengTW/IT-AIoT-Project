import tkinter as tk

import matplotlib
matplotlib.use('TkAgg')
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
from matplotlib.figure import Figure
import numpy as np
# seaborn example
import pandas as pd
import matplotlib.pyplot as plt
import Menu_Page
import ftplib  #
from linebot import LineBotApi#
from linebot.models import TextSendMessage, ImageSendMessage#


class PlotPage(object):
    def __init__(self, master=None):
        self.root = master
        self.root.title('Embedding in Tk')
        self.root.geometry(('1280x500'))
        self.root.geometry('+0+0')
        self.page = tk.Frame(self.root)
        self.page.pack(expand=True, fill=tk.BOTH)
        self.fig = self.create_plot()
        self.label = tk.Label(self.page, text="Matplotlib with Seaborn in Tkinter")
        self.label.pack()
        self.canvas = FigureCanvasTkAgg(self.fig, master=self.root)  # A tk.DrawingArea.
        
        self.canvas.get_tk_widget().pack(side=tk.TOP,fill=tk.BOTH,expand=1)
        self.canvas.draw()
        self.buttonA = tk.Button(self.page,text="返回選單", bg = 'LightBlue',font=('Arial',10), width=13,
                  height=2,command=self.BackToMenu)
        self.buttonA.pack(side=tk.RIGHT)
        self.buttonB = tk.Button(self.page,text="傳送至LINE", bg = 'LightGreen',font=('Arial',10), width=13,
                  height=2,command=self.transport_Line_FTP)
        self.buttonB.pack(side=tk.RIGHT)
        
    def BackToMenu(self):
        self.canvas.get_tk_widget().destroy()
        self.page.destroy()
        Menu_Page.MenuPage(self.root)
        
    def create_plot(self):
        
        with open('User/usr_test.txt', 'r') as usr_file:
            usr = usr_file.read()
        try:    
            df = pd.read_csv('UserRecord/'+usr+'.csv')
            df = df.dropna()
            if df.shape[0]<10:
                x=df['Date/Time']
                y=df['Result']
            else:
                x=df['Date/Time'][-10:]
                y=df['Result'][-10:]
        except:
                x=pd.Series({'Date/Time':None})
                y=pd.Series({'Result':None})
              
#               
#        f = plt.figure(  )
#        ax = f.add_axes([0.05, 0.18, 0.84, 0.80])
#        plt.xticks(rotation="vertical")
#        plt.plot(x, y,'bo')
#        plt.plot(x, y)
#        ax.set_xlabel('Date')
#        ax.set_ylabel('vision')
        #print(list(x.values))
        #x_number = [i for i in range(len(x.values))]
        #print(x_number)
        #x_number = [i for i in range(x.shape[0])]

        fig = Figure(figsize=(15,10),tight_layout=True)
        axes = fig.add_subplot(111)
        axes.plot(x, y,'bo')
        axes.plot(x, y)
        axes.tick_params(labelrotation=90)
        axes.set_xlabel('Date')
        axes.set_ylabel('vision')
        axes.set_title(usr+' vision')
        axes.set_yticks(np.arange(0.1,1.1,0.1))
        return fig

    
#'''
#使用Ngrok    
#'''    
#    def transport_Line(self):
#        self.fig.savefig('usr_test.jpg')
#        encoded_string = None
#        with open("usr_test.jpg", "rb") as image_file:
#            encoded_string = base64.b64encode(image_file.read())
#        filename='usr_test'
#        payload={'topic':'classification','message':filename, 'img':encoded_string.decode("utf-8")}
#        to_http.MessagePush(payload,method='mqtt')
#        payload_link={}
#        url='https://4ed62cea.ngrok.io/www/'+filename+ '.jpg'
#        payload_link['topic']='image'
#        payload_link['message']=url
#        to_http.MessagePush(payload_link,method='line')
        
        
    def transport_Line_FTP(self):
        self.fig.savefig('usr_test.jpg')
        self.session = ftplib.FTP('aiot01.com','med@aiot01.com','AI0312AI0312')
        self.file = open('usr_test.jpg','rb')                  # file to send
        self.session.storbinary('STOR usr_test.jpg', self.file)     # send the file
        self.file.close()                                 # close file and FTP
        self.session.quit()
        with open('User/usr_test.txt','r') as usr_file:
            usr = usr_file.read()
        CheckedUser = '用戶名稱 : %s \n'%(usr)
        
        Channel_access_token = "g7b9MysQYKOEs1zRV9IVVaQbZUNleS5fJbHG70mZsrkatN2BvxOdEi5tPQ0DXSD3qiGwgGzTlcCR70UlgZaqgwlQN1WomFyv45WIpnYl/852pkIJfd0OXhQtt8c7y+Oq/mnBNN7CzfCTxCV3dpw2ugdB04t89/1O/w1cDnyilFU="
        userID = "Ucc118f0dc0da83b6c2eaf414121490b1"	#your Line UserID
        line_bot_api = LineBotApi(Channel_access_token)

        txtMessage = TextSendMessage(
               text = CheckedUser + '視力趨勢')

        imgMessage = ImageSendMessage(
               original_content_url='https://med.aiot01.com/usr_test.jpg',
               preview_image_url='https://med.aiot01.com/usr_test.jpg')
        
        line_bot_api.push_message(userID, txtMessage)
        line_bot_api.push_message(userID, imgMessage)
        
 # --- main ---
  
      

if __name__ == '__main__':

    root = tk.Tk()
    obj = PlotPage(root)
    root.mainloop()   
