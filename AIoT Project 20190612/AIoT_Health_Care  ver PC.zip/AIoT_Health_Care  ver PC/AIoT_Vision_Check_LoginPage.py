# -*- coding: utf-8 -*-
import tkinter as tk
import pickle
import Menu_Page
import cv2
from PIL import Image, ImageTk
import time
import random
import face_recognition

class LoginPage(object):
    
    def __init__(self, master=None):
        # Image =======================================================================================
        self.Login_Img = tk.PhotoImage(file = './bin/icon/Login.png')
        self.Signup_Img = tk.PhotoImage(file = './bin/icon/Signup.png')
        self.FaceLogin_Img = tk.PhotoImage(file = './bin/icon/FaceLogin.png')
        self.camera = cv2.VideoCapture(1)
        self.UsingLock = False
        #variable======================================================================================
        self.var_usr_name = tk.StringVar()
        self.var_usr_name.set(' ')
        self.var_usr_pwd = tk.StringVar()
        self.face_detector = cv2.CascadeClassifier('./bin/haarcascade_frontalface_default.xml')
        self.FaceLoginEnable = False
        self.isCnt_page = False
        self.FaceImage_Recognition = None
        self.face_usr_info = None
        #Generate Frame ===============================================================================
        self.root = master 
        self.root.title('AIoT Health - Login')
        self.root.geometry(('1280x500'))
        self.root.resizable(False, False)
        self.page = tk.Frame(self.root)
        self.page.pack(expand=True, fill=tk.BOTH)
        
        # Image of AIoT ===============================================================================
        canvas = tk.Canvas(self.page, height=1500, width=638)
        self.image_file = tk.PhotoImage(file='bin\images\Login_Logo.png')
        canvas.create_image(0, 0, anchor='nw', image=self.image_file)
        canvas.place(x=0,y=0)
        
        #User name=====================================================================================
        Username = tk.Label(self.page, text='User name: ')
        Username.config(font=("Arial", 18))
        Username.place(x=650, y=320)     
        self.Entry_usr_name = tk.Entry(self.page, textvariable=self.var_usr_name, width=30)
        self.Entry_usr_name.config(font=("Helvetica", 18))
        self.Entry_usr_name.place(x=800, y=320)
        
        #Password======================================================================================
        Password = tk.Label(self.page, text='Password: ')
        Password.config(font=("Arial", 18))
        Password.place(x=650, y=370)
        Entry_usr_pwd = tk.Entry(self.page, textvariable=self.var_usr_pwd, show='*', width=30)
        Entry_usr_pwd.config(font=("Arial", 18))
        Entry_usr_pwd.place(x=800, y=370)
        
        #Button to login===============================================================================
        btn_login = tk.Button(self.page, text=' Login',image = self.Login_Img, 
                              command=self.usr_login, height=50, width=100, font=("Arial", 12), compound="left")
        btn_login.place(x=800, y=420)
        
        #Button to sign up=============================================================================
        self.btn_signup = tk.Button(self.page, text=' Sign up', image = self.Signup_Img, 
                                    command=self.usr_sign_up, height=50, width=100, font=("Arial", 12), compound="left")
        self.btn_signup.place(x=925, y=420)
        
        #Button to login by face ======================================================================
        btn_usr_face = tk.Button(self.page, text=' Face Login', image = self.FaceLogin_Img, 
                                 command=self.face_login, height=50, width=140, font=("Arial", 12), compound="left")
        btn_usr_face.place(x=1050, y=420)
        
        self.btn_signup.config(state=tk.NORMAL)
        
        self.FaceLoginPanel = tk.Label(self.page, width=32, height=12, bg='Black')
        
        self.FaceLoginPanel.place(x=850,y=50)
        
        self.faceVideo()
    
    # user login ======================================================================================
    def usr_login(self):
        self.usr_name = self.var_usr_name.get()
        self.usr_pwd = self.var_usr_pwd.get()
        try:
            with open('User/usrs_info.pickle', 'rb') as usr_file:
                self.usrs_info = pickle.load(usr_file)
        except FileNotFoundError:
            with open('usrs_info.pickle', 'wb') as usr_file:
                self.usrs_info = {'admin': 'admin'}
                pickle.dump(self.usrs_info, usr_file)
        if self.usr_name in self.usrs_info:
            if self.usr_pwd == self.usrs_info[self.usr_name]:
                tk.messagebox.showinfo(title='Welcome', message='How are you? ' + self.usr_name)
                with open('User/usr_test.txt','w') as usr_file:
                    usr_file.write(self.usr_name)
                self.page.destroy()
                Menu_Page.MenuPage(self.root)
            else:
                tk.messagebox.showerror(message='Error, your password is wrong, try again.')
        else:
           is_sign_up = tk.messagebox.askyesno('Welcome', 'You have not signed up yet. Sign up today?')
           if is_sign_up:
               self.usr_sign_up()
               
               
    def face_login(self):
        
        if not self.FaceLoginEnable:
            self.FaceLoginEnable = True
            self.isCnt_page = False
            self.Entry_usr_name.config(state=tk.DISABLED)
            
        else:
            self.FaceLoginEnable = False
            self.FaceLoginPanel.config(bg ='Black', width=240, height=180)
            self.Entry_usr_name.config(state=tk.NORMAL)
            
        
    def faceVideo(self):
        if self.FaceLoginEnable:
            success, frame = self.camera.read() 
            if success:
                frame  = cv2.flip(frame , 1)
                faces = self.face_detector.detectMultiScale(frame, scaleFactor=1.1, minNeighbors=5, minSize=(300,300))
                if len(faces) == 1:
                    if self.isCnt_page == False:
                        self.t1 = time.time()
                        self.isCnt_page = True
                    cnter = 3 - int(time.time() - self.t1)
                    for (x, y, w, h) in faces:
                        frame = cv2.rectangle(frame, (x, y), (x+w, y+h), (0, 255, 255), 2)
                        frame = cv2.putText(frame, str(cnter), (x+int(w/2), y-10), cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 255, 255), 2)
                    if cnter == 0:
                        self.FaceLoginEnable = False
                        self.FaceImage_Recognition = frame[y:y+w, x:x+h, :]
                        self.FaceCompare()
                else:
                    self.isCnt_page = False
                    
                frame = cv2.resize(frame, (240,180))
                cv2.waitKey(1)
                cv2image = cv2.cvtColor(frame, cv2.COLOR_BGR2RGBA)
                current_image = Image.fromarray(cv2image)
                imgtk = ImageTk.PhotoImage(image=current_image)
                self.FaceLoginPanel.imgtk = imgtk
                self.FaceLoginPanel.config(image=imgtk, width=240, height=180)
                self.FaceLoginPanel.image_names = imgtk        
                
        self.page.after(20, self.faceVideo)
        
    def FaceCompare(self):
        MinFaceDistance = 1
        with open('User/usrs_info.pickle', 'rb') as usr_file:
                self.face_usr_info = pickle.load(usr_file)
                
        for face in self.face_usr_info:
            if face[8:] == '.jpg':
                FaceInFolder = face_recognition.load_image_file('User/UserFace/'+face)
                FaceInFolder_Encoding = face_recognition.face_encodings(FaceInFolder)[0]
                FaceRecognite_Encoding = face_recognition.face_encodings(self.FaceImage_Recognition)[0]
                FaceDistances = face_recognition.face_distance([FaceInFolder_Encoding], FaceRecognite_Encoding)
                if FaceDistances < MinFaceDistance:
                    MinFaceDistance = FaceDistances
                    MinFaceDir = face
                    print(MinFaceDistance)
        if MinFaceDistance < 0.45:
            self.var_usr_name.set(self.face_usr_info[MinFaceDir])
        else:
            self.var_usr_name.set('Unknown********')
                
            
    # user sign up =====================================================================================           
    def usr_sign_up(self):
        self.isCnt = False
        self.TakePhoto = True
        self.FaceImage = None
        
        self.btn_signup.config(state=tk.DISABLED)
        self.window_sign_up = tk.Toplevel(self.root)
        self.window_sign_up.geometry('550x200')
        self.window_sign_up.title('Sign up window')
        self.window_sign_up.resizable(False, False)
        
        self.new_name = tk.StringVar()
        self.new_name.set('example@python.com')
        tk.Label(self.window_sign_up, text='User name: ').place(x=10, y= 10)
        entry_new_name = tk.Entry(self.window_sign_up, textvariable=self.new_name)
        entry_new_name.place(x=150, y=10)
        
        self.new_pwd = tk.StringVar()
        tk.Label(self.window_sign_up, text='Password: ').place(x=10, y=50)
        entry_usr_pwd = tk.Entry(self.window_sign_up, textvariable=self.new_pwd, show='*')
        entry_usr_pwd.place(x=150, y=50)

        self.new_pwd_confirm = tk.StringVar()
        tk.Label(self.window_sign_up, text='Confirm password: ').place(x=10, y= 90)
        entry_usr_pwd_confirm = tk.Entry(self.window_sign_up, textvariable=self.new_pwd_confirm, show='*')
        entry_usr_pwd_confirm.place(x=150, y=90)
        
        btn_comfirm_sign_up = tk.Button(self.window_sign_up, text='Sign up', command=self.sign_to_pickle)
        btn_comfirm_sign_up.place(x=150, y=130)
        
        btn_retake_sign_up = tk.Button(self.window_sign_up, text='Retake', command=self.Retake)
        btn_retake_sign_up.place(x=220, y=130)
        
        self.SignUpVideoPanel = tk.Label(self.window_sign_up, width=240, height=180)
        self.SignUpVideoPanel.place(x=300,y=10)
        if not self.UsingLock:
            self.UsingLock =True
            self.SignUpVideo()
        
        self.window_sign_up.protocol("WM_DELETE_WINDOW", self.on_closing)
        
    def on_closing(self):
        self.btn_signup.config(state=tk.NORMAL)
        self.UsingLock =False
       # self.camera.release()
        cv2.destroyAllWindows()
        self.window_sign_up.destroy()
        
        
    def Retake(self):
        self.TakePhoto = True
        self.isCnt = False
        
    def SignUpVideo(self):
        
        if self.TakePhoto:
            success, frame = self.camera.read() 
            if success:
                frame  = cv2.flip(frame , 1)
                faces = self.face_detector.detectMultiScale(frame, scaleFactor=1.1, minNeighbors=5, minSize=(300,300))
                if len(faces) == 1:
                    if self.isCnt == False:
                        self.t1 = time.time()
                        self.isCnt = True
                    cnter = 3 - int(time.time() - self.t1)
                    for (x, y, w, h) in faces:
                        frame = cv2.rectangle(frame, (x, y), (x+w, y+h), (0, 255, 255), 2)
                        frame = cv2.putText(frame, str(cnter), (x+int(w/2), y-10), cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 255, 255), 2)
                    if cnter == 0:
                        self.TakePhoto=False
                        self.FaceImage=frame[y:y+w, x:x+h, :]
                else:
                    self.isCnt = False
                    
                frame = cv2.resize(frame, (240,180))
                cv2.waitKey(1)
                cv2image = cv2.cvtColor(frame, cv2.COLOR_BGR2RGBA)
                current_image = Image.fromarray(cv2image)
                imgtk = ImageTk.PhotoImage(image=current_image)
                self.SignUpVideoPanel.imgtk = imgtk
                self.SignUpVideoPanel.config(image=imgtk)
                self.SignUpVideoPanel.image_names = imgtk
                
        self.window_sign_up.after(20, self.SignUpVideo)
        
    def sign_to_pickle(self):
        self.newpwd = self.new_pwd.get()
        self.newpwdcfm = self.new_pwd_confirm.get()
        self.newusrname = self.new_name.get()
        try:
            with open('User/usrs_info.pickle', 'rb') as usr_file:
                self.exist_usr_info = pickle.load(usr_file)
        except:
            self.exist_usr_info = {}
        if self.newpwd != self.newpwdcfm:
            tk.messagebox.showerror('Error', 'Password and confirm password must be the same!')
        elif self.newusrname in self.exist_usr_info:
            tk.messagebox.showerror('Error', 'The user has already signed up!')
        elif self.newpwd == '':
            tk.messagebox.showerror('Error', 'Password must be entered!')
        elif type(self.FaceImage) == type(None):
            tk.messagebox.showerror('Error', 'No face image!')
        else:
            self.RandomName = str(random.randint(10000000,99999999))+'.jpg'
            while (self.RandomName in self.exist_usr_info):
                self.RandomName = str(random.randint(10000000,99999999))+'.jpg'
            cv2.imwrite('User/UserFace/'+self.RandomName, self.FaceImage)   
            self.exist_usr_info[self.newusrname] = self.newpwd
            with open('User/usrs_info.pickle', 'wb') as usr_file:
                pickle.dump(self.exist_usr_info, usr_file)
                
            self.exist_usr_info[self.RandomName] = self.newusrname
            with open('User/usrs_info.pickle', 'wb') as usr_file:
                pickle.dump(self.exist_usr_info, usr_file)
            tk.messagebox.showinfo('Welcome', 'You have successfully signed up!')
            self.btn_signup.config(state=tk.NORMAL)
            self.UsingLock =False
            self.window_sign_up.destroy()
        

        
if __name__ == '__main__':

    root = tk.Tk()
    LoginPage(root)
    root.mainloop()  