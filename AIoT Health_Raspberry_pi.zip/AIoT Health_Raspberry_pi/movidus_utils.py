import mvnc.mvncapi as mvncapi

def get_mvnc_device():
    #mvncapi.SetGlobalOption(mvncapi.GlobalOption.LOG_LEVEL, 0)
    devices = mvncapi.EnumerateDevices()
    if (len(devices) < 1):
        print("Error - no NCS devices detected")
        quit()
    dev = mvncapi.Device(devices[0])
    try:
        dev.OpenDevice()
    except:
        print("Error - Could not open NCS device.")
        quit()
    return dev

def load_graph(dev, graph_file):
    with open(graph_file, mode='rb') as f:
        graph_file_buffer = f.read()
    graph = dev.AllocateGraph( graph_file_buffer )
    return graph
